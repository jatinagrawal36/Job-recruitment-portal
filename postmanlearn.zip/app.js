const express=require('express');
const app=express();
const path=require('path');
require('./mongo/mongo');
const Recent=require('./db/student');
app.use(express.json());
app.use(express.urlencoded({extended:false}));
const static_path=__dirname+'/newfile';

app.use(express.static(__dirname+'/newfile'));


app.get('/',(req,res)=>{
   res.send("HEllo");
    
  // res.sendFile('/home.html',{root:'newfile'});
})
/*
app.post('/register-done',async (req,res)=>{
    try{
         const User=new Recent({
            name: req.body.name,
            email: req.body.email,
            password: req.body.password

         })
            const user1= await User.save();
           
            res.sendFile(static_path+'/index.html');
        
    }
    catch(e){
        res.send(e);
    }
})

app.post('/login-done',async (req,res)=>{
    try{

         const email=req.body.email;
         const password=req.body.password;
         //res.send(req.body.email);/*
         const user=await Recent.findOne({email:email});
        // res.send(user.password);
        if(user.password==password)
        {
            res.sendFile(static_path+'/home.html');
        }
        else
        res.send("Login Invalid");
    }
    catch(e){
        res.send("login Invalid");
    }
})
*/
app.listen('8000');
