const mongo=require('mongoose');

const schema=new mongo.Schema({
    name:{
        type:String,
        isRequired:true,
        isUnique: true,
        mongooseOptions: { sparse: true }
    },
    email:{
        type:String,
        isUnique: true, 
        isRequired:true
        
    },
    password: {
        type:String,
        isUnique: true,
        isRequired:true
    }
})
const Recent2=new mongo.model('Recent2',schema);
module.exports=Recent2;