const mongo=require('mongoose');

mongo.connect('mongodb://localhost:27017/form',{
    useCreateIndex:true,
    useFindAndModify:true,
    useNewUrlParser:true,
    useUnifiedTopology:true
}).then(()=>{
    console.log("connected");
}).catch((e)=>{
    console.log(e);
})

